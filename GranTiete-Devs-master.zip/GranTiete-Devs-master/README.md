# GranTiete-Devs

dotnet add package Microsoft.EntityFrameworkCore --version 7.0.13

dotnet add package Microsoft.EntityFrameworkCore.Design --version 7.0.13

dotnet add package Pomelo.EntityFrameworkCore.MySql --version 7.0.0

dotnet add package Microsoft.AspNetCore.Identity.EntityFrameworkCore --version 7.0.13